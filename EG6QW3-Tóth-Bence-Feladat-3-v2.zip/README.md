# Vitmav42

This is my repository for a course with the code VITMAV42.

## INFO:

- Required node version in .nvmrc
- Install dependencies via `npm i`
- Run the project via `npm run start`
- Authenticated request: Middlewares that require authentication have a comment that states it is an Authenticated request. This means that no matter the implementation of the authentication, authentication will be applied (may be a password string match for demo/homework purposes, should be a third party Identity Provider usage in a more serious context).